#include <stdlib.h>

const char *
getprogname(void)
{
	return "?";
}
